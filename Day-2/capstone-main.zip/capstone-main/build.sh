#!/bin/bash
docker build -t test .
